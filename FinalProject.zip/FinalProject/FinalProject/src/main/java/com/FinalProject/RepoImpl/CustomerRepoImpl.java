package com.FinalProject.RepoImpl;

import org.springframework.stereotype.Component;

import com.FinalProject.Repo.CustomerRepo;

@Component
public class CustomerRepoImpl implements CustomerRepo {

}
