package com.FinalProject.Repo;

public interface DealerRepo {

}
