package com.FinalProject.Entity;

public class Customer {

}
