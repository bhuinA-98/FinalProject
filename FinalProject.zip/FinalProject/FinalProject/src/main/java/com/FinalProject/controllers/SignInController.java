package com.FinalProject.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class SignInController {

}
